#!/bin/bash
cd src
python3 main.py